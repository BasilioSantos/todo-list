export class Task {
  constructor () {
    this.id = '' // "5"
    this.title = ''
    this.completed = false
  }
}
