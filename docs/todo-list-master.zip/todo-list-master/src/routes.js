import App from './App.vue'
import CepChecker from './CepChecker.vue'

export default [
  { path: '/', component: App },
  { path: '/cep', component: CepChecker }
]
