// You MUST use interpolated strings as values in this file
module.exports = {
  NODE_ENV: `"testing"`
}
